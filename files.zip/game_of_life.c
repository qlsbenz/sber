#include <ncurses.h>
#include <stdio.h>

#define BOARD_ROWS 25
#define BOARD_COLS 80
#define MIN_DELAY_MS 50
#define MAX_DELAY_MS 1000
#define DELAY_STEP_MS 50
#define DEFAULT_DELAY_MS 200
#define CELL_ALIVE '#'
#define CELL_DEAD '.'

typedef int Grid[BOARD_ROWS][BOARD_COLS];

static void init_grid(Grid grid) {
    int r, c;
    for (r = 0; r < BOARD_ROWS; r++)
        for (c = 0; c < BOARD_COLS; c++) grid[r][c] = 0;
}

static void read_stdin_grid(Grid grid) {
    char line[BOARD_COLS + 2];
    int row = 0;
    while (row < BOARD_ROWS && fgets(line, (int)sizeof(line), stdin) != NULL) {
        int col;
        for (col = 0; col < BOARD_COLS && line[col] != '\0' && line[col] != '\n'; col++)
            grid[row][col] = (line[col] == '#' || line[col] == '1') ? 1 : 0;
        row++;
    }
}

static int count_neighbors(Grid grid, int r, int c) {
    int count = 0;
    int dr, dc;
    for (dr = -1; dr <= 1; dr++) {
        for (dc = -1; dc <= 1; dc++) {
            if (dr == 0 && dc == 0) continue;
            int nr = (r + dr + BOARD_ROWS) % BOARD_ROWS;
            int nc = (c + dc + BOARD_COLS) % BOARD_COLS;
            count += grid[nr][nc];
        }
    }
    return count;
}

static void next_generation(Grid cur, Grid nxt) {
    int r, c, n;
    for (r = 0; r < BOARD_ROWS; r++) {
        for (c = 0; c < BOARD_COLS; c++) {
            n = count_neighbors(cur, r, c);
            if (cur[r][c])
                nxt[r][c] = (n == 2 || n == 3) ? 1 : 0;
            else
                nxt[r][c] = (n == 3) ? 1 : 0;
        }
    }
}

static void copy_grid(Grid src, Grid dst) {
    int r, c;
    for (r = 0; r < BOARD_ROWS; r++)
        for (c = 0; c < BOARD_COLS; c++) dst[r][c] = src[r][c];
}

static void draw_grid(Grid grid, int gen, int delay_ms) {
    int r, c;
    clear();
    for (r = 0; r < BOARD_ROWS; r++)
        for (c = 0; c < BOARD_COLS; c++) mvaddch(r, c, grid[r][c] ? CELL_ALIVE : CELL_DEAD);
    mvprintw(BOARD_ROWS, 0, "Gen: %-6d | Delay: %4dms | [A]=faster  [Z]=slower  [SPACE]=quit", gen, delay_ms);
    refresh();
}

static void handle_input(int ch, int *delay_ms, int *running) {
    if (ch == ' ')
        *running = 0;
    else if ((ch == 'a' || ch == 'A') && *delay_ms > MIN_DELAY_MS)
        *delay_ms -= DELAY_STEP_MS;
    else if ((ch == 'z' || ch == 'Z') && *delay_ms < MAX_DELAY_MS)
        *delay_ms += DELAY_STEP_MS;
}

int main(void) {
    static Grid current, next_gen;
    int delay_ms = DEFAULT_DELAY_MS;
    int generation = 0;
    int running = 1;

    init_grid(current);
    read_stdin_grid(current);

    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    curs_set(0);

    while (running) {
        draw_grid(current, generation, delay_ms);
        int ch = getch();
        handle_input(ch, &delay_ms, &running);
        if (running) {
            next_generation(current, next_gen);
            copy_grid(next_gen, current);
            generation++;
            napms(delay_ms);
        }
    }

    endwin();
    return 0;
}
